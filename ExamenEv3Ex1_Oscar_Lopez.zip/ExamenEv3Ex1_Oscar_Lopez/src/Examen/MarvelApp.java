package Examen;

import java.util.*;

/**
 * @author oscar
 * @version 1.0
 * Clase que representa a un superhéroe de Marvel.
 */

//me daba fallos al ponerlo en otra clase
class Superheroe {
    private String nombre;
    private String alias;
    private String grupo;
    private List<String> poderes;
    
    /**
     * Constructor de la clase Superheroe.
     * @param nombre Nombre del superhéroe.
     * @param alias Alias del superhéroe.
     * @param grupo Grupo de pertenencia del superhéroe.
     * @param poderes Lista de poderes del superhéroe.
     */

    public Superheroe(String nombre, String alias, String grupo, List<String> poderes) {
        this.nombre = nombre;
        this.alias = alias;
        this.grupo = grupo;
        this.poderes = poderes;
    }

    public String getAlias() {
        return alias;
    }

    public List<String> getPoderes() {
        return poderes;
    }

    public String getNombre() {
        return nombre;
    }

    public String getGrupo() {
        return grupo;
    }
}
/**
 * Clase que representa la aplicación de consola para administrar información de superhéroes de Marvel.
 */
public class MarvelApp {
    private List<Superheroe> superheroes;
    private Scanner scanner;
    
    /**
     * Constructor de la clase MarvelApp.
     * Inicializa la lista de superhéroes y el objeto Scanner.
     */
    public MarvelApp() {
        superheroes = new ArrayList<>();
        scanner = new Scanner(System.in);
    }
    /**
    * Método para agregar un superhéroe a la lista.
    */
    public void agregarSuperheroe() {
        System.out.println("Ingrese el nombre del superhéroe:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese el alias del superhéroe:");
        String alias = scanner.nextLine();
        System.out.println("Ingrese el grupo del superhéroe:");
        String grupo = scanner.nextLine();

        List<String> poderes = new ArrayList<>();
        System.out.println("Ingrese los poderes del superhéroe (ingrese 'fin' para terminar):");
        String poder;
        while (!(poder = scanner.nextLine()).equalsIgnoreCase("fin")) {
            poderes.add(poder);
        }

        Superheroe superheroe = new Superheroe(nombre, alias, grupo, poderes);
        superheroes.add(superheroe);

        System.out.println("Superhéroe agregado correctamente.");
    }
    /**
     * Método para buscar un superhéroe por su alias.
     */
    public void buscarPorAlias() {
        System.out.println("Ingrese el alias del superhéroe a buscar:");
        String alias = scanner.nextLine();

        boolean encontrado = false;
        for (Superheroe superheroe : superheroes) {
            if (superheroe.getAlias().equalsIgnoreCase(alias)) {
                encontrado = true;
                System.out.println("Nombre: " + superheroe.getNombre());
                System.out.println("Grupo: " + superheroe.getGrupo());
                System.out.println("Poderes: " + superheroe.getPoderes());
                break;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontró ningún superhéroe con ese alias.");
        }
    }
    /**
     * Método para buscar superhéroes por un poder específico.
     */
    public void buscarPorPoder() {
        System.out.println("Ingrese el poder a buscar:");
        String poderBuscado = scanner.nextLine();

        boolean encontrado = false;
        for (Superheroe superheroe : superheroes) {
            if (superheroe.getPoderes().contains(poderBuscado)) {
                encontrado = true;
                System.out.println("Nombre: " + superheroe.getNombre());
                System.out.println("Alias: " + superheroe.getAlias());
                System.out.println("Grupo: " + superheroe.getGrupo());
                System.out.println("Poderes: " + superheroe.getPoderes());
                System.out.println();
            }
        }

        if (!encontrado) {
            System.out.println("No se encontró ningún superhéroe con ese poder.");
        }
    }
    /**
     * Método principal que ejecuta la aplicación.
     */
    public void ejecutar() {
        int opcion;
        do {
            System.out.println("Seleccione una opción:");
            System.out.println("1. Agregar personaje");
            System.out.println("2. Buscar por alias");
            System.out.println("3. Buscar por poder");
            System.out.println("4. Salir");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea pendiente

            switch (opcion) {
                case 1:
                    agregarSuperheroe();// Llama al método para agregar un nuevo superhéroe
                    break;
                case 2:
                    buscarPorAlias();// Llama al método para buscar un superhéroe por su alias
                    break;
                case 3:
                    buscarPorPoder();// Llama al método para buscar un superhéroe por su poder
                    break;
                case 4:
                    System.out.println("Saliendo...");// Mensaje de salida
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");// Mensaje para opción inválida
                    break;
            }
        } while (opcion != 4);
    }
    
    /**
     * Método principal que crea una instancia de MarvelApp y la ejecuta.
     * @param args Argumentos de línea de comandos (no utilizados).
     */
    public static void main(String[] args) {
        MarvelApp app = new MarvelApp();
        app.ejecutar();
    }
} 
